// JavaScript Document
$(document).ready(function () {
    $wh = $(window).height();
    $ww = $(window).width();
    $winw = $(window).innerWidth();
    $('.openSlide').css({ 'display': 'block', 'width': '100%' });
   
    $('.openSlide .st-content, .openSlide, .st-open').css({ 'width': $ww, 'min-height': $wh - 40, 'background-size': 'cover' });
    $('#logo').css('cursor','pointer');
    $('#logo').click(function () {
        window.location.href = "index.html";
    });
    $('#submitBtn').click(function () {
       // alert();
        window.location.href = "brochures.html";
    });
    $('.project-thumb-list').click(function () {
        window.location.href = "project.html";
    });
    $('#ldCloud').addClass('ldnohover');
    

    /*
    $('#accordianInfo a').click(function(){
    $('#firstSlide').slideUp();
    var target = $('#accordianInfo');
    $('.st-accordion ul li').css('height','40');
    //$('.st-accordion ul li').slideUp();
    $(this).parent().css('height',$wh-40);
    $('html,body').animate({ scrollTop: target.offset().top }, 1000);
    });
	
    $('#accordianGallery a').click(function(){
    $('#firstSlide').slideUp();
    var target = $('#accordianGallery');
    $('.st-accordion ul li').css('height','40');
    //$('.st-accordion ul li').slideUp();
    $(this).parent().css('height',$wh-40);
    $('html,body').animate({ scrollTop: target.offset().top }, 1000);
    });
		
    $('#accordianVideos a').click(function(){
    $('#firstSlide').slideUp();
    var target = $('#accordianVideos');
    $('.st-accordion ul li').css('height',40);
    //$('.st-accordion ul li').slideUp();
    $(this).parent().css('height',$wh-40);
    $('html,body').animate({ scrollTop: target.offset().top }, 1000);
    });

    $('#accordianKeypoints a').click(function(){
    $('#firstSlide').slideUp();
    var target = $('#accordianKeypoints');
    $('.st-accordion ul li').css('height',40);
    //$('.st-accordion ul li').slideUp();
    $(this).parent().css('height',$wh-40);
    $('html,body').animate({ scrollTop: target.offset().top }, 1000);
    });
	
    $('#accordianEndorsement a').click(function(){
    $('#firstSlide').slideUp();
    var target = $('#accordianEndorsement');
    $('.st-accordion ul li').css('height',40);
    //$('.st-accordion ul li').slideUp();
    $(this).parent().css('height',$wh-40);
    $('html,body').animate({ scrollTop: target.offset().top }, 1000);
    });
    */

    /* Projects Main Page */
    //alert($winw+' & '+$ww);
    $ldcloudHeight = $('#ldCloud').height();
    setTimeout(function () {
        //alert();
        //$('#ldCloud').animate({ 'bottom': 48-$ldcloudHeight }, 500, 'linear');
        $('#ldCloud').css({ 'bottom': '-156px' });
        //alert($ldcloudHeight);
    }, 2000);

    /*$('#ldCloud').mouseover(function () {
        
        $('#ldCloud').css({ 'bottom': 0 });
        $(this).removeClass('ldnohover');
        $(this).addClass('ldhover');
    });
    setTimeout(function () {
        
        if ($('#ldCloud').hasClass('ldnohover')) {
            $('#ldCloud').css({ 'bottom': '-250px' });
        }
        
    }, 5000);*/
    $cloudHeaderHeight = $('#ldCloud h3').height();
    $ldcloudafterLeavepos = $ldcloudHeight-$cloudHeaderHeight
    $('#ldCloud').mouseover(function () {

        $('#ldCloud').css({ 'bottom': 0 });
        //$(this).removeClass('ldnohover');
        $(this).addClass('ldhover');
    });
    $('#ldCloud').mouseleave(function () {

        setTimeout(function () {

            if ($('#ldCloud').hasClass('ldhover')) {
                $('#ldCloud').css({ 'bottom': -$ldcloudafterLeavepos });
            }

        }, 2000);
        
    });
    /**/
    

    /*ldcloudOpen = false;
    $('#ldCloud').mouseover(function () {
        
        if (ldcloudOpen == false) {
            $('#ldCloud').stop().animate({ 'bottom': 0 }, 500, 'linear');
            ldcloudOpen = true;
        }else{
            $('#ldCloud').stop().animate({ 'bottom': 48 - $ldcloudHeight }, 500, 'linear');
        ldcloudOpen = false;
    }
    });*/
    


    $('#cLogin_btn').click(function () {
        $('#cLogin').show();
    });
    $('#cancelBtn').click(function () {
        $('#cLogin').hide();
    });

    $('#cLogin strong').text('Client login')
    $('.fixed-width-container').css({ 'width': $ww - 100 });

    
    //$('.project-thumb-list:nth-child(9), .project-thumb-list:nth-child(10)').css('margin-right','0');

    if ($ww > 800) {
        $('.project-thumb-list').css({ 'width': ($winw - 20) / 4 });
        $pim = $('.project-thumb-list img').height();
        $('.project-thumb-list').css({ 'height': '230px' });
        $('#hs1').css({'background-image':'url(images/homepage_sketch.png)'})

    }  else {
        $('.project-thumb-list').css({ 'width': ($winw - 10) / 2 });
        $pim = $('.project-thumb-list img').height();
        $('.project-thumb-list').css({ 'height': '200px' });
        $('#hs1').css({ 'background-image': 'url(images/homepage_sketch_mobile.png)' })
    }

    //alert($pim);

    $("#loginForm").submit(function () {
        //alert("Handler for .submit() called.");
       // event.preventDefault();
    });

});

