﻿function initSlider() {
    //alert();
    $('.flexslider').flexslider({
        animation: "slide",
        pauseOnAction: false,
        controlNav: false,
        slideshow: false,
        directionNav: true,
        slideshowSpeed: 3000,
        //controlsContainer:'dotstyle-flip'
        start: function (slider) {
            //$('body').removeClass('loading');
            $nwh = $(window).height();
            $nww = $(window).width() - 80;
            $bgheight = $(window).height() - 160;
            $('.flex-viewport, .slides li').css({ 'max-width': '100%', 'width': '100%', 'height': $nwh - 160, 'position': 'relative', 'border': '0', 'background-size': 'cover', 'background-position': 'center center', 'background-repeat': 'no-repeat', 'overflow': 'hidden' });
            $('.slides li').css({ 'max-width': $nww });
            //$lih = $('.flex-viewport, .slides li').height();
            //alert($lih);
            //$('.slides').css({ 'max-width': '100%' });
            $('.flex-direction-nav li a').css({ 'background-color': 'transparent', 'position': 'absolute', 'padding': 0, 'line-height': 'normal', 'font-size': '5px' })
            //alert($nwh);
        }
    });
};

$(function () {

    $('#st-accordion').accordion({
        oneOpenedItem: true
    });

});

$(document).ready(function () {
    $wh = $(window).height();
    $ww = $(window).width();
    $winw = $(window).innerWidth();
    //$('.flex-viewport, .slides li').css({ 'width': '100%', 'height': $nwh - 160, 'position': 'relative', 'border': '0', 'background-size': 'cover', 'background-position': 'center center' });
});

$(document).ready(function () {
    //$('.slides li').css({'width':'1000px'});
    //$('#video').css({ 'max-width': '100%', 'width': '100%', 'height': $nwh - 160, 'position': 'relative', 'border': '0', 'background-size': 'cover', 'background-position': 'center center', 'background-repeat': 'no-repeat','overflow':'hidden' });
    $(".imageGallery").click(function () {
        initSlider();
    });
    $video_url = $('#video').attr('src') + "?autoplay=1";
    $('#video').attr('src', '');
    $('#st-accordion ul li a').click(function () {
        $('#video').attr('src', '');
    })
    $('#videoAccor a').click(function () {
        $('#video').attr('src', $video_url);
    })
});